var firebaseConfig = {
    apiKey: "AIzaSyB6k1Q91ZUeRsKneY7El6adwQ1CONAt650",
    authDomain: "freefoodforyou-6dc88.firebaseapp.com",
    projectId: "freefoodforyou-6dc88",
    storageBucket: "freefoodforyou-6dc88.appspot.com",
    messagingSenderId: "1097439533486",
    appId: "1:1097439533486:web:5dd7c3ce83cc6cf2ff503f",
    measurementId: "G-K2439YYX8Q"
  };

const app = firebase.initializeApp(firebaseConfig);